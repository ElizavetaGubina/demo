require('dotenv').config();
const express = require('express');
const session = require('express-session');
const mysql = require('mysql2');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Настройка EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: process.env.SESSION_SECRET || 'secret',
    resave: false,
    saveUninitialized: false,
    cookie: { maxAge: 1000 * 60 * 60 * 24 }
}));

// Middleware для передачи user в шаблоны
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next();
});

// Подключение к БД
const pool = mysql.createPool({
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || 'xix',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Проверка подключения
pool.getConnection((err, connection) => {
    if (err) {
        console.error('❌ Ошибка подключения к MySQL:', err.message);
    } else {
        console.log('✅ Подключение к MySQL успешно!');
        connection.release();
    }
});

// Промис-обертка для запросов
const query = (sql, params) => {
    return new Promise((resolve, reject) => {
        pool.query(sql, params, (err, results) => {
            if (err) reject(err);
            else resolve(results);
        });
    });
};

// Middleware для проверки авторизации
const isAuth = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/login');
    }
};

const isAdmin = (req, res, next) => {
    if (req.session.user && req.session.user.role === 'admin') {
        next();
    } else {
        res.status(403).send('Доступ запрещен');
    }
};

// ================ МАРШРУТЫ ================

// Главная страница
app.get('/', (req, res) => {
    res.render('index', { 
        title: 'Главная',
        success: null,
        error: null
    });
});

// Вход
app.get('/login', (req, res) => {
    if (req.session.user) return res.redirect('/dashboard');
    res.render('login', { 
        title: 'Вход',
        error: req.query.error || null,
        success: req.query.success || null
    });
});

// Регистрация
app.get('/register', (req, res) => {
    if (req.session.user) return res.redirect('/dashboard');
    res.render('register', { 
        title: 'Регистрация',
        error: null,
        success: null
    });
});

// Личный кабинет
app.get('/dashboard', isAuth, async (req, res) => {
    try {
        const requests = await query(
            'SELECT * FROM service_requests WHERE user_id = ? ORDER BY created_at DESC',
            [req.session.user.id]
        );
        
        res.render('dashboard', { 
            title: 'Личный кабинет',
            requests: requests || [],
            success: req.query.success || null,
            error: req.query.error || null
        });
    } catch (err) {
        console.error(err);
        res.render('dashboard', { 
            title: 'Личный кабинет',
            requests: [],
            error: 'Ошибка загрузки заявок',
            success: null
        });
    }
});

// Создание заявки
app.get('/create-request', isAuth, async (req, res) => {
    try {
        const deviceTypes = await query('SELECT * FROM device_types ORDER BY name');
        
        res.render('create-request', { 
            title: 'Новая заявка',
            deviceTypes: deviceTypes || [],
            error: req.query.error || null,
            success: null
        });
    } catch (err) {
        console.error(err);
        res.render('create-request', { 
            title: 'Новая заявка',
            deviceTypes: [],
            error: 'Ошибка загрузки',
            success: null
        });
    }
});

// Админ панель
app.get('/admin', isAdmin, async (req, res) => {
    try {
        const requests = await query(`
            SELECT sr.*, u.login, u.full_name 
            FROM service_requests sr
            JOIN users u ON sr.user_id = u.id
            ORDER BY sr.created_at DESC
        `);
        
        res.render('admin', { 
            title: 'Панель администратора',
            requests: requests || [],
            success: req.query.success || null,
            error: req.query.error || null
        });
    } catch (err) {
        console.error(err);
        res.render('admin', { 
            title: 'Панель администратора',
            requests: [],
            error: 'Ошибка загрузки',
            success: null
        });
    }
});

// ================ API МАРШРУТЫ ================

// Регистрация
app.post('/register', async (req, res) => {
    try {
        const { login, password, full_name, phone, email } = req.body;
        
        if (!login || !password || !full_name || !phone || !email) {
            return res.render('register', {
                title: 'Регистрация',
                error: 'Все поля обязательны',
                success: null
            });
        }
        
        const existing = await query(
            'SELECT id FROM users WHERE login = ? OR email = ?',
            [login, email]
        );
        
        if (existing.length > 0) {
            return res.render('register', {
                title: 'Регистрация',
                error: 'Логин или email уже используются',
                success: null
            });
        }
        
        await query(
            'INSERT INTO users (login, password, full_name, phone, email) VALUES (?, ?, ?, ?, ?)',
            [login, password, full_name, phone, email]
        );
        
        res.redirect('/login?success=Регистрация успешна! Войдите в систему.');
    } catch (err) {
        console.error(err);
        res.render('register', {
            title: 'Регистрация',
            error: 'Ошибка регистрации',
            success: null
        });
    }
});

// Авторизация
app.post('/login', async (req, res) => {
    try {
        const { login, password } = req.body;
        
        // Админ (хардкод)
        if (login === 'Admin' && password === 'TechNET') {
            const admin = await query(
                'SELECT id FROM users WHERE login = ? AND role = ?',
                ['Admin', 'admin']
            );
            
            let adminId;
            if (admin.length === 0) {
                const result = await query(
                    'INSERT INTO users (login, password, full_name, phone, email, role) VALUES (?, ?, ?, ?, ?, ?)',
                    ['Admin', 'TechNET', 'Администратор', '89991234567', 'admin@mail.ru', 'admin']
                );
                adminId = result.insertId;
            } else {
                adminId = admin[0].id;
            }
            
            req.session.user = { 
                id: adminId, 
                login: 'Admin', 
                role: 'admin' 
            };
            return res.redirect('/admin');
        }
        
        // Обычный пользователь
        const users = await query(
            'SELECT * FROM users WHERE login = ? AND password = ?',
            [login, password]
        );
        
        if (users.length === 0) {
            return res.redirect('/login?error=Неверный логин или пароль');
        }
        
        const user = users[0];
        req.session.user = {
            id: user.id,
            login: user.login,
            role: user.role
        };
        
        res.redirect('/dashboard');
    } catch (err) {
        console.error(err);
        res.redirect('/login?error=Ошибка авторизации');
    }
});

// Выход
app.get('/logout', (req, res) => {
    req.session.destroy();
    res.redirect('/');
});

// Создание заявки
app.post('/create-request', isAuth, async (req, res) => {
    try {
        const { device_type, service_date, payment_method } = req.body;
        
        if (!device_type || !service_date || !payment_method) {
            return res.redirect('/create-request?error=Заполните все поля');
        }
        
        await query(
            'INSERT INTO service_requests (user_id, device_type, service_date, payment_method) VALUES (?, ?, ?, ?)',
            [req.session.user.id, device_type, service_date, payment_method]
        );
        
        res.redirect('/dashboard?success=Заявка создана');
    } catch (err) {
        console.error(err);
        res.redirect('/create-request?error=Ошибка создания заявки');
    }
});

// Изменение статуса (админ)
app.post('/admin/update-status', isAdmin, async (req, res) => {
    try {
        const { request_id, status } = req.body;
        
        await query(
            'UPDATE service_requests SET status = ? WHERE id = ?',
            [status, request_id]
        );
        
        res.redirect('/admin?success=Статус обновлен');
    } catch (err) {
        console.error(err);
        res.redirect('/admin?error=Ошибка обновления статуса');
    }
});

// Запуск сервера
app.listen(PORT, () => {
    console.log(`🚀 Сервер запущен: http://localhost:${PORT}`);
    console.log(`👤 Админ: логин "Admin", пароль "TechNET"`);
});